<footer class="footer_area white_f">
	<div class="container-fluid">
	<div class="footer_widgets row">
		<aside class="f_widgets_item">
			<div class="f_logo">
				<a href="./index-rtl.php"><img class="img-fluid" src="img/logo.png" alt="" /></a>
			</div>
		</aside>
		
		<aside class="f_widgets_item">
			
			<div class="f_contact">

				<div class="f_title">
					<h3><?php echo $footer[0]->footer_title_ar; ?></h3>
				</div>
				<p><?php echo $footer[0]->footer_title_ar; ?></p>
			</div>
		</aside>
		<aside class="f_widgets_item">
			<div class="f_link">
			<div class="f_title">
					<h3><?php echo $footer[1]->footer_title_ar; ?></h3>
				</div>
				<ul class="list">
				
				<li>
					<a href="http://paul-themes.com/cdn-cgi/l/email-protection#f29a979e9e9db29b9c86809b93818687969b9ddc919d" class="__cf_email__" data-cfemail="543c3138383b143d3a20263d35272021303d3b7a373b"><?php echo $footer[1]->footer_mail; ?></span></a>
				</li>
				<li><a href="tel:9123548073"><?php echo $footer[2]->footer_mobile; ?></a></li>
				<li><p><?php echo $footer[1]->footer_fixed; ?></p></li>
				</ul>
			</div>
		</aside>
		<aside class="f_widgets_item">
			<div class="f_link">
				<div class="f_title">
					<h3><?php echo $footer[2]->footer_title_ar; ?></h3>
				</div>
				<ul class="list">
                <li><a href="<?php echo $footer[2]->twitter_link; ?>"><i class="ion-social-twitter"> تويتر</i></a></li>
                <li><a href="<?php echo $footer[2]->fb_link; ?>"><i class="ion-social-facebook"> فيسبوك</i></a></li>
                <li><a href="<?php echo $footer[2]->insta_link; ?>"><i class="ion-social-instagram"> انستغرام</i></a></li>
                <li><a href="<?php echo $footer[2]->tmb_link; ?>"><i class="ion-social-tumblr"> تمبلر</i></a></li>
                <li><a href="<?php echo $footer[2]->pin_link; ?>"><i class="ion-social-pinterest"> بينترست</i></a></li>
                </ul>
			</div>
		</aside>
		<!-- <aside class="f_widgets_item">
			
			<div class="f_link">
				<div class="f_title">
					<h3>المساعدة</h3>
				</div>
				<ul class="list">
					<li><a href="#">FAQs</a></li>
					<li><a href="#" id="priv">المفاهيم & الشروط</a></li>
					<li><a href="#" id="priv">سياسة الخصوصية</a></li>
					<li><a href="#">مساعدة</a></li>
					<li><a href="#">خدمات</a></li>
				</ul>
			</div>
		</aside> -->
	</div>
	<div class="footer_copyright">
		<div class="left_text">
			<p>&copy; حقوق النشر 2018، جميع الحقوق محفوظة ل <a href="./index-rtl.php">ديمجدي</a>، تم تطويره من قبل <a href="https://www.targusme.com/"><img src="./img/targus_logo.ico" /></a></p>
		</div>
		<!-- <div class="middle_text">
			<ul class="list">
				<li><a href="#">تويتر</a></li>
				<li><a href="#">فيسبوك</a></li>
				<li><a href="#">انستغرام</a></li>
				<li><a href="#">تمبلر</a></li>
				<li><a href="#">بينترست</a></li>
			</ul>
		</div> -->
		<!-- <div class="right_text">
			<ul class="list">
				<li class="active"><a href="index.php">En</a></li>
			</ul>
		</div> -->
	</div>
	</div>
</footer> 
