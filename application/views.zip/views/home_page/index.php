<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from paul-themes.com/html/Dimajde/Dimajde-demo/Dimajde/light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Aug 2018 11:12:29 GMT -->
<?php include 'template/head.php'; ?>
<body>
	<div class="layout animsition">
		<div id="small-dialog" class="zoom-anim-dialog mfp-hide embed-responsive embed-responsive-16by9">
			<iframe src="https://player.vimeo.com/video/34741214?color=ffffff&amp;title=0&amp;byline=0&amp;portrait=0"></iframe>
		</div>
		<?php include 'template/header.php'; ?>
		<div class="click-capture"></div>
		<div class="side_menu">
			<span class="close-menu lnr lnr-cross right-boxed"></span>
			<div class="menu-lang right-boxed">
				<a href="index-rtl.php" class="active">Ar</a>
			</div>
			<ul class="menu-list right-boxed">
				<li class="active">
					<a href="index.php">Home </a>
				</li>
				<li><a href="about-us.php">About</a></li>
				<li><a href="work-list.php">Product</a></li>
				<li>
					<a href="index.php">Projects</a>
				</li>

				<li><a href="contact.php">Contact</a></li>
			</ul>
			<div class="menu-footer right-boxed">
				<div class="social-list">
					<a href="#" class="icon ion-social-twitter"></a>
					<a href="#" class="icon ion-social-facebook"></a>
					<a href="#" class="icon ion-social-googleplus"></a>
					<a href="#" class="icon ion-social-linkedin"></a>
					<a href="#" class="icon ion-social-dribbble-outline"></a>
				</div>
				<div><p>©copyrights 2018, All Rights Reserved for <a href="./index.php">Dimajde</a> Developed by <a href="https://www.targusme.com/"><img src="./img/targus_logo.ico" /></a></p></div>
			</div>
		</div>


		<section class="home_slider">
			<div id="home_full_slider" class="rev_slider fullscreenbanner" data-version="5.3.1.6">
				<ul> 
					<li data-index="rs-2946" data-transition="slotzoom-horizontal" data-slotamount="5" data-masterspeed="1000" data-fsmasterspeed="1000">
						<img src="img/home-slider/slider-1.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="10" data-no-retina>
						<div class="slider_text_box">
							<div class="tp-caption tp-resizeme text_1" data-x="['left']" data-hoffset="['-5','0','15','15','15']" data-y="['bottom']" data-voffset="['-10','0','0','0','0']" data-textAlign="['left']" data-fontsize="['100', '100','70','70','50']" data-lineheight="['100','100', '70','70','50']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="font-family: 'Oswald', sans-serif; font-weight: 700; text-transform: uppercase;">
								Brian’s Villa<br>Private Residence
							</div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_1" data-x="['left']" data-hoffset="['0']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .10);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_2" data-x="['left']" data-hoffset="['397']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .10);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_3" data-x="['left']" data-hoffset="['795']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .10);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_4" data-x="['left']" data-hoffset="['1168']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .10);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme text_2" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['top','top','top','top']" data-voffset="['325','285','160','160','110']" data-width="86" data-height="6" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:#231f20;"> </div>
							<div class="tp-caption tp-resizeme count" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['top']" data-voffset="['355','330','200','200','150']" data-textAlign="['left']" data-fontsize="['60', '60','60','60']" data-lineheight="['60','60', '60','60']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05">
								1/3
							</div>

							<div class="tp-caption tp-resizeme text_3" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['bottom']" data-voffset="['240','240','240','240','170']" data-textAlign="['left']" data-fontsize="['18, 18, 20,22']" data-lineheight="['32','32', '32','32']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:[-155%];z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="chars" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="letter-spacing:0.1em; text-transform:uppercase;">Residence
							</div>
							<div class="tp-caption video" data-x="['right']" data-hoffset="['0','0','15']" data-y="[middle']" data-voffset="[-100']" data-textAlign="['center']" data-fontsize="['100', '100','100','100']" data-lineheight="['100','100', '100','100']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="2000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05"><a class="popup-with-move-anim" href="#small-dialog"><img src="img/icon/video-1.png" alt=""></a>
							</div>
						</div>
					</li>
					<li data-index="rs-2947" data-transition="slotzoom-horizontal" data-slotamount="5" data-masterspeed="1000" data-fsmasterspeed="1000">

						<img src="<?php echo base_url() ?>assets/img/home-slider/slider-2.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="10" data-no-retina>


						<div class="slider_text_box">
							<div class="tp-caption tp-resizeme text_1" data-x="['left']" data-hoffset="['-5','0','15','15','15']" data-y="['bottom']" data-voffset="['-10','0','0','0','0']" data-textAlign="['left']" data-fontsize="['100', '100','70','70','50']" data-lineheight="['100','100', '70','70','50']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="font-family: 'Oswald', sans-serif; font-weight: 700; text-transform: uppercase;">
								tim’s Villa <br />in netherland
							</div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_1" data-x="['left']" data-hoffset="['0']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .20);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_2" data-x="['left']" data-hoffset="['397']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .20);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_3" data-x="['left']" data-hoffset="['795']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .20);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_4" data-x="['left']" data-hoffset="['1168']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .20);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme text_2" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['top','top','top','top']" data-voffset="['325','285','160','160','110']" data-width="86" data-height="6" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:#231f20;"> </div>
							<div class="tp-caption tp-resizeme count" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['top']" data-voffset="['355','330','200','200','150']" data-textAlign="['left']" data-fontsize="['60', '60','60','60']" data-lineheight="['60','60', '60','60']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05">
								2/3
							</div>

							<div class="tp-caption tp-resizeme text_3" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['bottom']" data-voffset="['240','240','240','240','170']" data-textAlign="['left']" data-fontsize="['18, 18, 20,22']" data-lineheight="['32','32', '32','32']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:[-155%];z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="chars" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="letter-spacing:0.1em; text-transform:uppercase;">Residence
							</div>
							<div class="tp-caption video" data-x="['right']" data-hoffset="['0','0','15']" data-y="[middle']" data-voffset="[-100']" data-textAlign="['center']" data-fontsize="['100', '100','100','100']" data-lineheight="['100','100', '100','100']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="2000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05"><a class="popup-with-move-anim" href="#small-dialog"><img src="img/icon/video-1.png" alt=""></a>
							</div>
						</div>
					</li>
					<li data-index="rs-2948" data-transition="slotzoom-horizontal" data-slotamount="5" data-masterspeed="1000" data-fsmasterspeed="1000">

						<img src="img/home-slider/slider-3.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="10" data-no-retina>


						<div class="slider_text_box">
							<div class="tp-caption tp-resizeme text_1" data-x="['left']" data-hoffset="['-5','0','15','15','15']" data-y="['bottom']" data-voffset="['-10','0','0','0','0']" data-textAlign="['left']" data-fontsize="['100', '100','70','70','50']" data-lineheight="['100','100', '70','70','50']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="font-family: 'Oswald', sans-serif; font-weight: 700; text-transform: uppercase;">
								private residence <br />in romania
							</div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_1" data-x="['left']" data-hoffset="['0']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .20);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_2" data-x="['left']" data-hoffset="['397']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .20);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_3" data-x="['left']" data-hoffset="['795']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .20);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme line_4" data-x="['left']" data-hoffset="['1168']" data-y="['top','top','top','top']" data-voffset="['-50']" data-width="2" data-height="5000px" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:rgba(255, 255, 255, .20);"> </div>
							<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme text_2" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['top','top','top','top']" data-voffset="['325','285','160','160','110']" data-width="86" data-height="6" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:#231f20;"> </div>
							<div class="tp-caption tp-resizeme count" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['top']" data-voffset="['355','330','200','200','150']" data-textAlign="['left']" data-fontsize="['60', '60','60','60']" data-lineheight="['60','60', '60','60']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05">
								3/3
							</div>

							<div class="tp-caption tp-resizeme text_3" data-x="['left']" data-hoffset="['0','0','15','15','15']" data-y="['bottom']" data-voffset="['240','240','240','240','170']" data-textAlign="['left']" data-fontsize="['18, 18, 20,22']" data-lineheight="['32','32', '32','32']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:[-155%];z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="chars" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="letter-spacing:0.1em; text-transform:uppercase;">Residence
							</div>
							<div class="tp-caption video" data-x="['right']" data-hoffset="['0','0','15']" data-y="[middle']" data-voffset="[-100']" data-textAlign="['center']" data-fontsize="['100', '100','100','100']" data-lineheight="['100','100', '100','100']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[-100%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="2000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05"><a class="popup-with-move-anim" href="#small-dialog"><img src="img/icon/video-1.png" alt=""></a>
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="year">
				<a href="#">2018</a>
			</div>
			<div class="social_icon">
				<ul class="list">
					<li><a href="#"><i class="ion-social-twitter"></i></a></li>
					<li><a href="#"><i class="ion-social-facebook"></i></a></li>
					<li><a href="#"><i class="ion-social-googleplus"></i></a></li>
				</ul>
			</div>
		</section>


		<section class="intes_studio_area white_cl">
			<div class="since_text">
				<h5>Since 2004</h5>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-lg-7">
						<div class="studio_img">
							<img src="img/studio-1.jpg" alt="">
							<div class="years_text">
								<div class="years_text_inner">
									<h1>10</h1>
									<h2>Years</h2>
									<h4>working</h4>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-5">
						<div class="studio_text">
							<h6 class="s_title white">Dimajde Studio</h6>
							<h3>Make is a different kind of architecture practice</h3>
							<h5>We know that good design means good business</h5>
							<p>Founded by Robert Downey Jr in 2004, we’re an employee-owned firm pursuing a democratic design process that values everyone’s input. Today we have more than 150 people in London, Hong Kong and Sydney providing architecture, interior & urban design services from concept to completion.</p>
							<a class="br_btn white" href="#">more about us</a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<div class="pfsh-counter-area" id="pfsh-counter">
			<div class="pfsh-counter-overlay">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-xs-6 counter  text-center">
							<i class="fa fa-code fa-2x"></i>
							<h2 class="timer count-title count-number" data-to="11300" data-speed="6000"></h2>
							<p class="count-text ">Project</p>
						</div>

						<div class="counter col-md-3 col-xs-6 text-center">
							<i class="fa fa-coffee fa-2x"></i>
							<h2 class="timer count-title count-number" data-to="1700" data-speed="6000"></h2>
							<p class="count-text ">client </p>
						</div>

						<div class="counter col-md-3 col-xs-6 text-center">
							<i class="fa fa-lightbulb-o fa-2x"></i>
							<h2 class="timer count-title count-number" data-to="11900" data-speed="6000"></h2>
							<p class="count-text ">Product</p>
						</div>

						<div class="counter col-md-3 col-xs-6 end text-center">
							<i class="fa fa-coffee fa-2x"></i>
							<h2 class="timer count-title count-number" data-to="157" data-speed="6000"></h2>
							<p class="count-text "> Hours Of Work</p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<section class="speciallization_area white_cl">
			<div class="container">

				<h6 class="s_title white">Our Speciallization</h6>
				<div class="row">
					<div class="col-md-4 col-xs-6">
						<div class="spec_item">
							<div class="spec_text text-center">
								<img src="img/icon/spec-d-1.png" alt="">
								<h4>Architecture</h4>
								<p>Inter’s singular aim is to design the best buildings, places and spaces in the world. A central part of this is providing the complete design of buildings across a range of sectors.</p>
								<a class="view_btn white" href="#">Read more</a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-xs-6">
						<div class="spec_item">
							<div class="spec_text text-center">
								<img src="img/icon/spec-d-2.png" alt="">
								<h4>Interior</h4>
								<p>We offer a fully integrated service that complements the overarching architectural concept, ensuring each project is finished to a high level of quality and detail. </p>
								<a class="view_btn white" href="#">Read more</a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-xs-6">
						<div class="spec_item">
							<div class="spec_text text-center">
								<img src="img/icon/spec-d-3.png" alt="">
								<h4>Urban Design</h4>
								<p>Working with client and community, we deliver masterplans that create vibrant new places and spaces, attract people, and encourage investment through popularity and increased activity</p>
								<a class="view_btn white" href="#">Read more</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>


		<section class="latest_project white_cl">
			<div class="container">
				<div class="l_text">
					<div class="float-md-left">
						<div class="main_title white">
							<h2>Latest projects</h2>
						</div>
					</div>
					<div class="float-md-right">
						<ul class="portfolio_filter list">
							<li class="active" data-filter="*"><a href="#">All</a></li>
							<li data-filter=".arc"><a href="#">Commercial</a></li>
							<li data-filter=".urban"><a href="#">Industry</a></li>
							<li data-filter=".res"><a href="#">Residential</a></li>
							<li data-filter=".inter"><a href="#">Interior</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="fillter_slider owl-carousel">
				<div class="item arc urban res">
					<div class="projects_item">
						<img src="img/latest-project/l-project-1.jpg" alt="">
						<div class="hover">
							<a href="#"><i class="ion-android-arrow-forward"></i></a>
							<div class="project_text">
								<h5>Interior - Architecture</h5>
								<a href="#"><h4>Private Residence In North London</h4></a>
							</div>
						</div>
					</div>
				</div>
				<div class="item arc res">
					<div class="projects_item">
						<img src="img/latest-project/l-project-2.jpg" alt="">
						<div class="hover">
							<a href="#"><i class="ion-android-arrow-forward"></i></a>
							<div class="project_text">
								<h5>Interior - Architecture</h5>
								<a href="#"><h4>Private Residence In North London</h4></a>
							</div>
						</div>
					</div>
				</div>
				<div class="item res arc inter urban">
					<div class="projects_item">
						<img src="img/latest-project/l-project-3.jpg" alt="">
						<div class="hover">
							<a href="#"><i class="ion-android-arrow-forward"></i></a>
							<div class="project_text">
								<h5>Interior - Architecture</h5>
								<a href="#"><h4>Private Residence In North London</h4></a>
							</div>
						</div>
					</div>
				</div>
				<div class="item arc res urban">
					<div class="projects_item">
						<img src="img/latest-project/l-project-4.jpg" alt="">
						<div class="hover">
							<a href="#"><i class="ion-android-arrow-forward"></i></a>
							<div class="project_text">
								<h5>Interior - Architecture</h5>
								<a href="#"><h4>Private Residence In North London</h4></a>
							</div>
						</div>
					</div>
				</div>
				<div class="item inter inter">
					<div class="projects_item">
						<img src="img/latest-project/l-project-4.jpg" alt="">
						<div class="hover">
							<a href="#"><i class="ion-android-arrow-forward"></i></a>
							<div class="project_text">
								<h5>Interior - Architecture</h5>
								<a href="#"><h4>Private Residence In North London</h4></a>
							</div>
						</div>
					</div>
				</div>
				<div class="item inter">
					<div class="projects_item">
						<img src="img/latest-project/l-project-3.jpg" alt="">
						<div class="hover">
							<a href="#"><i class="ion-android-arrow-forward"></i></a>
							<div class="project_text">
								<h5>Interior - Architecture</h5>
								<a href="#"><h4>Private Residence In North London</h4></a>
							</div>
						</div>
					</div>
				</div>
				<div class="item inter res">
					<div class="projects_item">
						<img src="img/latest-project/l-project-1.jpg" alt="">
						<div class="hover">
							<a href="#"><i class="ion-android-arrow-forward"></i></a>
							<div class="project_text">
								<h5>Interior - Architecture</h5>
								<a href="#"><h4>Private Residence In North London</h4></a>
							</div>
						</div>
					</div>
				</div>
				<div class="item inter urban">
					<div class="projects_item">
						<img src="img/latest-project/l-project-2.jpg" alt="">
						<div class="hover">
							<a href="#"><i class="ion-android-arrow-forward"></i></a>
							<div class="project_text">
								<h5>Interior - Architecture</h5>
								<a href="#"><h4>Private Residence In North London</h4></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>


		<!-- <section class="our_press_area white_cl">
			<div class="container">
				<h6 class="s_title white">Our Press</h6>
				<div class="row">
					<div class="col-lg-6">
						<div class="press_img_item">
							<div class="press_img">
								<img class="img-fluid" src="img/press.jpg" alt="">
							</div>
							<div class="date">
								<a href="#">august 19, 2018</a>
								<i class="ion-record"></i>
								<a href="#">news</a>
							</div>
							<a href="#"><h4>HPG Australia announces winning design team on One Sydney Park</h4></a>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="press_item_inner">
							<div class="press_item">
								<div class="date">
									<a href="#">july 30, 2018</a>
									<i class="ion-record"></i>
									<a href="#">event</a>
								</div>
								<a href="#"><h4>CTBUH International Conference 2017</h4></a>
							</div>
							<div class="press_item">
								<div class="date">
									<a href="#">july 20, 2018</a>
									<i class="ion-record"></i>
									<a href="#">News</a>
								</div>
								<a href="#"><h4>Changing it up: Make commissions artist Garth Knight for groundbreaking new display suite</h4></a>
							</div>
							<div class="press_item">
								<div class="date">
									<a href="#">july 26, 2018</a>
									<i class="ion-record"></i>
									<a href="#">News</a>
								</div>
								<a href="#"><h4>LandAid SleepOut</h4></a>
							</div>
							<div class="press_item">
								<div class="date">
									<a href="#">May 19, 2018</a>
									<i class="ion-record"></i>
									<a href="#">News</a>
								</div>
								<a href="#"><h4>Planning approved for restoration of Hornsey Town Hall</h4></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section> -->


		<section class="clients_area white_cl">
			<div class="container">
				<div class="main_title white">
					<h2>+2,500 Happy clients</h2>
				</div>
				<div class="testimonials_slider owl-carousel">
					<div class="item">
						<div class="test_item">
							<h4><span>Ryan Betthalyn</span> / Director at Chobham Manor</h4>
							<p>Sed elit quam, iaculis sed semper sit amet udin vitae nibh. Rubino staveuo at magna akal semperFusce commodo molestie luctus.Lorem ipsum ulicon Dolor tusima olatiup.</p>
						</div>
					</div>
					<div class="item">
						<div class="test_item">
							<h4><span>Bobs Hanley</span> / Owner of Edden Villa</h4>
							<p>Paras stalor ed elit quam, iaculis sed semper sit amet udin vitae nibh. at magna akal semperFusce commodo molestie luctus.Lorem ipsum vitalun Dolor tusima olatiup aculis sed semper sit ame</p>
						</div>
					</div>
				</div>
				<div class="instruction text-center">
					<h4><i class="ion-mouse"></i> click on image and move <i class="ion-arrow-right-a"></i></h4>
				</div>
				<div class="clients_slider owl-carousel">
					<div class="item">
						<img src="img/clients-logo/c-logo-d-1.png" alt="">
					</div>
					<div class="item">
						<img src="img/clients-logo/c-logo-d-2.png" alt="">
					</div>
					<div class="item">
						<img src="img/clients-logo/c-logo-d-3.png" alt="">
					</div>
					<div class="item">
						<img src="img/clients-logo/c-logo-d-4.png" alt="">
					</div>
					<div class="item">
						<img src="img/clients-logo/c-logo-d-5.png" alt="">
					</div>
				</div>
			</div>
		</section>
		<?php include 'template/footer.php'; ?>
		<div class="page_lines white_br">
			<div class="container">
				<div class="row m0">
					<div class="col-lg-4">
						<div class="line"></div>
					</div>
					<div class="col-lg-4">
						<div class="line"></div>
					</div>
					<div class="col-lg-4">
						<div class="line"></div>
						<div class="line"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php include 'template/js-files.php'; ?>
</body>

<!-- Mirrored from paul-themes.com/html/Dimajde/Dimajde-demo/Dimajde/light/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Aug 2018 11:13:53 GMT -->
</html>
