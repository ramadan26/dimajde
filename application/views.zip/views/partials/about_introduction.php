<section class="about_image">
	<img class="img-fluid" src="<?php echo base_url(); ?>assets/img/About_page/<?php if(isset($intro->img)) echo $intro->img; ?>" alt="">
</section>
<section class="about_studio_area white_cl">
	<div class="container">
		<div class="ab_studio_text text-center">
			<h2 class=" white"><?php echo lang($intro, 'title'); ?></h2>
			<p class="lead"><?php echo lang($intro, 'desc'); ?>
		</p>
		<p class="lead"><?php echo lang($intro, 'desc1'); ?>
	</p>
</div>
