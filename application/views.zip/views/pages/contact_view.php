<body>
    <div class="animsition">
<?php $this->load->view('partials/navbar_about'); ?>
<?php $this->load->view('partials/contact'); ?>
<?php $this->load->view('partials/footer'); ?>
	</div>
</body>
