<body>
	<!--<div id="small-dialog" class="zoom-anim-dialog mfp-hide embed-responsive embed-responsive-16by9">-->
	<!--	<iframe src="https://player.vimeo.com/video/34741214?color=ffffff&amp;title=0&amp;byline=0&amp;portrait=0"></iframe>-->
	<!--</div>-->
    <div class="animsition">

	<?php $this->load->view('partials/navbar'); ?>
	<?php $this->load->view('partials/slider'); ?>
	<?php $this->load->view('partials/homeabout'); ?>
	<?php $this->load->view('partials/homecount'); ?>
	<?php $this->load->view('partials/homespec'); ?>
	
	<?php $this->load->view('partials/client_slide'); ?>
	<?php $this->load->view('partials/brand_slide'); ?>
	<?php $this->load->view('partials/footer'); ?>
	</div>
</body>
