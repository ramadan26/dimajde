<body>
    <div class="animsition">
<?php $this->load->view('partials/navbar_about'); ?>
<?php $this->load->view('partials/project_details') ?>
<?php $this->load->view('partials/project_details1') ?>
<?php $this->load->view('partials/footer'); ?>
	</div>
</body>
