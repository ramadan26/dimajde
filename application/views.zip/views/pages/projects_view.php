<body>
  <div class="animsition">
<?php $this->load->view('partials/navbar_about'); ?>
<?php $this->load->view('partials/projects'); ?>
<?php $this->load->view('partials/footer'); ?>
	</div>
</body>
