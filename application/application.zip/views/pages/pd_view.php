<body>
    <div class="animsition">
<?php $this->load->view('partials/navbar'); ?>
<?php $this->load->view('partials/product_details') ?>
<?php $this->load->view('partials/product_details1') ?>
<?php $this->load->view('partials/footer'); ?>
	</div>
</body>
