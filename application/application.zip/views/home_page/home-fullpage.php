<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from paul-themes.com/html/Dimajde/Dimajde-demo/Dimajde/light/home-fullpage.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Aug 2018 11:15:09 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="#" type="image/x-icon" />

<title>Dimajde </title>

<link href="vendors/linear-icon/style.css" rel="stylesheet">
<link href="vendors/ionicons/css/ionicons.min.css" rel="stylesheet">
<link href="vendors/elegant-icon/style.css" rel="stylesheet">

<link href="css/bootstrap.min.css" rel="stylesheet">

<link href="vendors/revolution/css/settings.css" rel="stylesheet">
<link href="vendors/revolution/css/layers.css" rel="stylesheet">
<link href="vendors/revolution/css/navigation.css" rel="stylesheet">

<link href="vendors/popup/magnific-popup.css" rel="stylesheet">
<link href="vendors/owl-carousel/owl.carousel.min.css" rel="stylesheet">
<link rel="stylesheet" href="vendors/pagepiling/jquery.pagepiling.css">
<link rel="stylesheet" href="vendors/animsition/css/animsition.min.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">


<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>
<body class="full_pad">
<div id="small-dialog" class="zoom-anim-dialog mfp-hide embed-responsive embed-responsive-16by9">
<iframe src="https://player.vimeo.com/video/34741214?color=ffffff&amp;title=0&amp;byline=0&amp;portrait=0"></iframe>
</div>

<div class="animations animsition">
<div class="box_lay">
<header class="full_header content-white">
<div class="float-left">
<a class="logo" href="#"><img src="img/logo.png" alt=""><img src="img/logo.png" alt=""></a>
<a class="phone" href="tel:3689565656"><i class="lnr lnr-phone-handset"></i> (+070) 3689 56 56 56</a>
</div>
<div class="float-right">
<div class="bar_menu">
<i class="lnr lnr-menu"></i>
</div>
</div>
</header>
<div class="click-capture"></div>
<div class="side_menu">
<span class="close-menu lnr lnr-cross right-boxed"></span>
<div class="menu-lang right-boxed">
<a href="#" class="active">Eng</a>
<a href="#">Fra</a>
<a href="#">ger</a>
</div>
<ul class="menu-list right-boxed">
<li class="active">
<a href="index.html">Home</a>
<ul class="list">
<!--li><a href="index.html">Default</a></li-->
<!--li><a href="http://paul-themes.com/html/Dimajde/Dimajde-demo/Dimajde/dark/index.html">Default Dark</a></li>
<li class="active"><a href="home-fullpage.html">Parallax</a></li>
<li><a href="http://paul-themes.com/html/Dimajde/Dimajde-demo/Dimajde/dark/home-fullpage.html">Parallax Dark</a></li-->
</ul>
</li>
<li><a href="about-us.html">About</a></li><li><a href="studio.html">Studio</a></li><li><a href="work-list.html">Product</a></li>
<li>
<a href="index.html">Projects <i class="ion-chevron-down"></i></a>
<ul class="list">
<li><a href="work-grid.html">Work Grid</a></li>
 
<li><a href="work-masonry.html">Work Masonry</a></li>
<li><a href="project-detail.html">Project Details</a></li>
</ul>
</li>
<li>
<a href="index.html">Blog <i class="ion-chevron-down"></i></a>
<ul class="list">
<li><a href="blog-grid.html">Blog Grid</a></li>
<li><a href="blog-masonry.html">Blog Masonry</a></li>
<li><a href="blog-with-sidebar.html">Blog With Sidebar</a></li>
<li><a href="single-blog-gallery.html">Single Blog Gallery</a></li>
<li><a href="single-blog-image.html">Single Blog Image</a></li>
<li><a href="single-blog-video.html">Single Blog Video</a></li>
</ul>
</li>
<li><a href="contact.html">Contact</a></li>
</ul>
<div class="menu-footer right-boxed">
<div class="social-list">
<a href="#" class="icon ion-social-twitter"></a>
<a href="#" class="icon ion-social-facebook"></a>
<a href="#" class="icon ion-social-googleplus"></a>
<a href="#" class="icon ion-social-linkedin"></a>
<a href="#" class="icon ion-social-dribbble-outline"></a>
</div>
<div class="copy">© Dimajde 2018. All Rights Reseverd</div>
</div>
</div>
<div class="pagepiling">
<div class="pp-scrollable p-table text-white section section-1">
<div class="scroll-wrap">
<div class="section-bg" style="background-image:url(img/fullpage/bg-img-1.jpg);"></div>
<div class="scrollable-content">
<div class="vertical-centred">
<div class="box_content">
<div class="container">
<div class="row">
<div class="col-lg-10">
<div class="inter_content">
<h2>Dimajde Studio</h2>
<p>We know that good design means <br /> good business</p>
<a class="popup-with-move-anim" href="#small-dialog">more about us <i class="ion-android-arrow-dropright-circle"></i></a>
</div>
</div>
<div class="col-lg-2">
<div class="full_10_box">
<h2>10</h2>
<h3>years</h3>
<h5>working</h5>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="pp-scrollable section text-white section-2">
<div class="scroll-wrap">
<div class="scrollable-content bg_gray">
<div class="vertical-centred">
<div class="full_spec_area box_content">
<div class="container">
<div class="main_title white">
<h2>Our Speciallization</h2>
</div>
<div class="row">
<div class="col-lg-4 col-md-6">
<div class="spec_item">
<img src="img/icon/spec-d-1.png" alt="">
<h4>Architecture</h4>
<p>Inter’s singular aim is to design the best buildings, places and spaces in the world. A central part of this is providing the complete design of buildings across a range of sectors.</p>
<a class="view_btn white" href="#">View project</a>
</div>
</div>
<div class="col-lg-4 col-md-6">
<div class="spec_item">
<img src="img/icon/spec-d-2.png" alt="">
<h4>Interior</h4>
<p>We offer a fully integrated service that complements the overarching architectural concept, ensuring each project is finished to a high level of quality and detail. </p>
<a class="view_btn white" href="#">View project</a>
</div>
</div>
<div class="col-lg-4 col-md-6">
<div class="spec_item">
<img src="img/icon/spec-d-3.png" alt="">
<h4>Urban Design</h4>
<p>Working with client and community, we deliver masterplans that create vibrant new places and spaces, attract people, and encourage investment through popularity and increased activity</p>
<a class="view_btn white" href="#">View project</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
 </div>
<div class="pp-scrollable text-white section section-3 slider">
<div class="scroll-wrap">
<div class="full_slider_inner">
<div class="rev_slider_wrapper">
<div id="full_page_slider" class="rev_slider fullscreenbanner" data-version="5.3.1.6">
<ul> 
<li data-index="rs-2946" data-transition="slotzoom-horizontal" data-masterspeed="1000" data-slotamount="5" data-fsmasterspeed="1000">

<img src="img/fullpage/bg-img-2.jpg" data-bgparallax="5" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>


<div class="slider_text_box">
<div class="tp-caption tp-resizeme text_1" data-x="['left']" data-hoffset="['18']" data-y="['bottom']" data-voffset="['-6','-6','-6','-6','-10']" data-textAlign="['left']" data-fontsize="['100', '100','70','70','50']" data-lineheight="['100','100', '70','70','50']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="font-family: 'Oswald', sans-serif; font-weight: 700; text-transform: uppercase;">
Brian’s Villa<br>Private Residence
</div>
<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme text_2" data-x="['left']" data-hoffset="['24']" data-y="['top','top','top','top','top']" data-voffset="['330','290','150','200','150']" data-width="86" data-height="6" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:#231f20;"> </div>
<div class="tp-caption tp-resizeme count" data-x="['left']" data-hoffset="['23']" data-y="['top']" data-voffset="['370','340','180','230','185']" data-textAlign="['left']" data-fontsize="['60', '60','60','60']" data-lineheight="['60','60', '60','60']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05">
1/3
</div>

<div class="tp-caption tp-resizeme text_3" data-x="['left']" data-hoffset="['23']" data-y="['bottom']" data-voffset="['245','245','185','185','150']" data-textAlign="['left']" data-fontsize="['18','18','18','18']" data-lineheight="['28','28','28','28']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:[-155%];z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="chars" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="letter-spacing:0.1em; text-transform:uppercase;">civil
</div>
<div class="tp-caption ContentZoom-SmallIcon tp-resizeme rs-parallaxlevel-0 left_ar" data-x="['right','right','right','right','right']" data-y="['center','center','center','center']" data-voffset="['-80','-80','-80','-80']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;" data-style_hover="c:rgba(111, 124, 130, 1.00);cursor:pointer;" data-transform_in="opacity:0;s:500;e:Power1.easeInOut;" data-transform_out="opacity:0;s:500;e:Power1.easeInOut;s:500;e:Power1.easeInOut;" data-start="0" data-splitin="none" data-splitout="none" data-actions='[{"event":"click","action":"jumptoslide","slide":"previous","delay":""}]' data-responsive_offset="on"><i class="ion-chevron-left"></i>
</div>
<div class="tp-caption ContentZoom-SmallIcon tp-resizeme rs-parallaxlevel-0 right_ar" data-x="['right','right','right','right','right']" data-y="['center','center','center','center']" data-hoffset="[30',30','100','15','15']" data-voffset="['-80','-80','-80','-80']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;" data-style_hover="c:rgba(111, 124, 130, 1.00);cursor:pointer;" data-transform_in="opacity:0;s:500;e:Power1.easeInOut;" data-transform_out="opacity:0;s:500;e:Power1.easeInOut;s:500;e:Power1.easeInOut;" data-start="0" data-splitin="none" data-splitout="none" data-actions='[{"event":"click","action":"jumptoslide","slide":"next","delay":""}]' data-responsive_offset="on"><i class="ion-chevron-right"></i>
</div>
</div>
</li>
<li data-index="rs-2947" data-transition="slotzoom-horizontal" data-masterspeed="1000" data-slotamount="5" data-fsmasterspeed="1000">

<img src="img/home-slider/slider-2.jpg" data-bgparallax="5" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>


<div class="slider_text_box">
<div class="tp-caption tp-resizeme text_1" data-x="['left']" data-hoffset="['18']" data-y="['bottom']" data-voffset="['-6','-6','-6','-6','-10']" data-textAlign="['left']" data-fontsize="['100', '100','70','70','50']" data-lineheight="['100','100', '70','70','50']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="font-family: 'Oswald', sans-serif; font-weight: 700; text-transform: uppercase;">
tim’s Villa <br />in netherland
</div>
<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme text_2" data-x="['left']" data-hoffset="['24']" data-y="['top','top','top','top','top']" data-voffset="['330','290','150','200','150']" data-width="86" data-height="6" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:#231f20;"> </div>
<div class="tp-caption tp-resizeme count" data-x="['left']" data-hoffset="['23']" data-y="['top']" data-voffset="['370','340','180','230','185']" data-textAlign="['left']" data-fontsize="['60', '60','60','60']" data-lineheight="['60','60', '60','60']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05">
2/3
</div>

<div class="tp-caption tp-resizeme text_3" data-x="['left']" data-hoffset="['23']" data-y="['bottom']" data-voffset="['245','245','185','185','150']" data-textAlign="['left']" data-fontsize="['18, 18, 20,22']" data-lineheight="['32','32', '32','32']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:[-155%];z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="chars" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="letter-spacing:0.1em; text-transform:uppercase;">Residence
</div>
<div class="tp-caption ContentZoom-SmallIcon tp-resizeme rs-parallaxlevel-0 left_ar" data-x="['right','right','right','right','right']" data-y="['center','center','center','center']" data-voffset="['-80','-80','-80','-80']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;" data-style_hover="c:rgba(111, 124, 130, 1.00);cursor:pointer;" data-transform_in="opacity:0;s:500;e:Power1.easeInOut;" data-transform_out="opacity:0;s:500;e:Power1.easeInOut;s:500;e:Power1.easeInOut;" data-start="0" data-splitin="none" data-splitout="none" data-actions='[{"event":"click","action":"jumptoslide","slide":"previous","delay":""}]' data-responsive_offset="on"><i class="ion-chevron-left"></i>
</div>
<div class="tp-caption ContentZoom-SmallIcon tp-resizeme rs-parallaxlevel-0 right_ar" data-x="['right','right','right','right','right']" data-y="['center','center','center','center']" data-hoffset="[30',30','100','15','15']" data-voffset="['-80','-80','-80','-80']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;" data-style_hover="c:rgba(111, 124, 130, 1.00);cursor:pointer;" data-transform_in="opacity:0;s:500;e:Power1.easeInOut;" data-transform_out="opacity:0;s:500;e:Power1.easeInOut;s:500;e:Power1.easeInOut;" data-start="0" data-splitin="none" data-splitout="none" data-actions='[{"event":"click","action":"jumptoslide","slide":"next","delay":""}]' data-responsive_offset="on"><i class="ion-chevron-right"></i>
</div>
</div>
</li>
<li data-index="rs-2948" data-transition="slotzoom-horizontal" data-slotamount="5" data-masterspeed="1000" data-fsmasterspeed="1000">

<img src="img/home-slider/slider-2.jpg" data-bgparallax="5" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>

<div class="slider_text_box">
<div class="tp-caption tp-resizeme text_1" data-x="['left']" data-hoffset="['18']" data-y="['bottom']" data-voffset="['-6','-6','-6','-6','-10']" data-textAlign="['left']" data-fontsize="['100', '100','70','70','50']" data-lineheight="['100','100', '70','70','50']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="font-family: 'Oswald', sans-serif; font-weight: 700; text-transform: uppercase;">
private residence <br />in romania
</div>
<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme text_2" data-x="['left']" data-hoffset="['24']" data-y="['top','top','top','top','top']" data-voffset="['330','290','150','200','150']" data-width="86" data-height="6" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":500,"ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="background-color:#231f20;"> </div>
<div class="tp-caption tp-resizeme count" data-x="['left']" data-hoffset="['23']" data-y="['top']" data-voffset="['370','340','180','230','185']" data-textAlign="['left']" data-fontsize="['60', '60','60','60']" data-lineheight="['60','60', '60','60']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[155%];x:0;z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:1000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05">
3/3
</div>

<div class="tp-caption tp-resizeme text_3" data-x="['left']" data-hoffset="['23']" data-y="['bottom']" data-voffset="['245','245','185','185','150']" data-textAlign="['left']" data-fontsize="['18, 18, 20,22']" data-lineheight="['32','32', '32','32']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:[-155%];z:0;rX:0deg;rY:0deg;rZ:0deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power2.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" data-start="1500" data-splitin="chars" data-splitout="none" data-responsive_offset="on" data-elementdelay="0.05" style="letter-spacing:0.1em; text-transform:uppercase;">civil
</div>
<div class="tp-caption ContentZoom-SmallIcon tp-resizeme rs-parallaxlevel-0 left_ar" data-x="['right','right','right','right','right']" data-y="['center','center','center','center']" data-voffset="['-80','-80','-80','-80']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;" data-style_hover="c:rgba(111, 124, 130, 1.00);cursor:pointer;" data-transform_in="opacity:0;s:500;e:Power1.easeInOut;" data-transform_out="opacity:0;s:500;e:Power1.easeInOut;s:500;e:Power1.easeInOut;" data-start="0" data-splitin="none" data-splitout="none" data-actions='[{"event":"click","action":"jumptoslide","slide":"previous","delay":""}]' data-responsive_offset="on"><i class="ion-chevron-left"></i>
</div>
<div class="tp-caption ContentZoom-SmallIcon tp-resizeme rs-parallaxlevel-0 right_ar" data-x="['right','right','right','right','right']" data-y="['center','center','center','center']" data-hoffset="[30',30','100','15','15']" data-voffset="['-80','-80','-80','-80']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;" data-style_hover="c:rgba(111, 124, 130, 1.00);cursor:pointer;" data-transform_in="opacity:0;s:500;e:Power1.easeInOut;" data-transform_out="opacity:0;s:500;e:Power1.easeInOut;s:500;e:Power1.easeInOut;" data-start="0" data-splitin="none" data-splitout="none" data-actions='[{"event":"click","action":"jumptoslide","slide":"next","delay":""}]' data-responsive_offset="on"><i class="ion-chevron-right"></i>
</div>
</div>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div class="pp-scrollable section text-white section-4">
<div class="scroll-wrap">
<div class="scrollable-content bg_gray">
<div class="vertical-centred">
<div class="box_content">
<div class="container">
<div class="full_testimonials_area">
<div class="main_title white">
<h2>Testimonials</h2>
</div>
<div class="testimonials_slider owl-carousel full_white">
<div class="item">
<div class="test_item">
<h4><span>Ryan Betthalyn</span> / Director at Chobham Manor</h4>
<p>Sed elit quam, iaculis sed semper sit amet udin vitae nibh. Rubino staveuo at magna akal semperFusce commodo molestie luctus.Lorem ipsum ulicon Dolor tusima olatiup.</p>
</div>
</div>
<div class="item">
<div class="test_item">
<h4><span>Bobs Hanley</span> / Owner of Edden Villa</h4>
<p>Paras stalor ed elit quam, iaculis sed semper sit amet udin vitae nibh. at magna akal semperFusce commodo molestie luctus.Lorem ipsum vitalun Dolor tusima olatiup aculis sed semper sit ame</p>
</div>
</div>
</div>
<div class="clients_slider owl-carousel">
<div class="item">
<img src="img/clients-logo/c-logo-d-1.png" alt="">
</div>
<div class="item">
<img src="img/clients-logo/c-logo-d-2.png" alt="">
</div>
<div class="item">
<img src="img/clients-logo/c-logo-d-3.png" alt="">
</div>
<div class="item">
<img src="img/clients-logo/c-logo-d-4.png" alt="">
</div>
<div class="item">
<img src="img/clients-logo/c-logo-d-5.png" alt="">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="pp-scrollable section text-white section-5">
<div class="scroll-wrap">
<div id="mapBox" class="mapBox" data-lat="40.701083" data-lon="-74.1522848" data-zoom="14" data-marker="" data-info="54B, Tailstoi Town 5238 La city, IA 522364" data-mlat="" data-mlon="">
</div>
<div class="scrollable-content bg_gray">
<div class="vertical-centred">
<div class="contact_area box_content">
<div class="container">
<div class="row">
<div class="col-lg-5">
<div class="left_contact_details">
<h1>Contact</h1>
<h2><span>New York,</span> United States</h2>
<p>No. 1002, Dahill Rd Str, Borough Park,<br /> NY 9982, USA</p>
<a href="tel:3689565656">(+070) 3689 56 56 56</a>
<a href="http://paul-themes.com/cdn-cgi/l/email-protection#9bf8f4f5effaf8efdbf2f5effee9e8efeefff2f4b5f8f4"><span class="__cf_email__" data-cfemail="bad9d5d4cedbd9cefad3d4cedfc8c9cecfded3d594d9d5">[email&#160;protected]</span></a>
<a class="map_btn" href="https://www.google.com/maps/place/রাশিয়া/@49.7916688,68.7571364,3z/data=!3m1!4b1!4m5!3m4!1s0x453c569a896724fb:0x1409fdf86611f613!8m2!3d61.52401!4d105.318756" target="_blank">Map Direction <i class="ion-chevron-right"></i></a>
</div>
</div>
<div class="col-lg-7">
<div class="right_contact_form">
<h4>Send a message for us</h4>
<form class="row contact_us_form js-form">
<div class="form-group col-md-6">
<input type="text" class="form-control" id="name" name="name" placeholder="Adam Warlock" required>
</div>
<div class="form-group col-md-6">
<input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
</div>
<div class="form-group col-md-12">
<textarea class="form-control" name="message" id="message" rows="1" placeholder="Here goes your message" required></textarea>
</div>
<div class="form-group col-md-12">
<button type="submit" value="submit" class="btn order_s_btn form-control">Send Message <i class="ion-ios-play"></i></button>
</div>
<div class="success-message"><i class="fa fa-check text-primary"></i> Thank you!. Your message is successfully sent...</div>
<div class="error-message">We're sorry, but something went wrong</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<footer class="full_footer content-white">
<div class="float-left">
<h5>©2018 <a href="#">Dimajde</a></h5>
</div>
<div class="float-right">
<ul class="list">
<li><a href="#">Twitter</a></li>
<li><a href="#">Facebook</a></li>
<li><a href="#">Instagram</a></li>
</ul>
</div>
</footer>
</div>
</div>


<script data-cfasync="false" src="../../../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/jquery-3.3.1.min.js"></script>

<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="vendors/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="vendors/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="vendors/revolution/js/extensions/revolution.extension.parallax.min.js"></script>

<script src="vendors/popup/jquery.magnific-popup.min.js"></script>
<script src="vendors/parallax/parallax.min.js"></script>
<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
<script src="vendors/isotope/isotope.pkgd.min.js"></script>
<script src="vendors/pagepiling/jquery.pagepiling.min.js"></script>
<script src="vendors/animsition/js/animsition.min.js"></script>
<script src="js/smoothscroll.js"></script>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
<script src="js/gmaps.min.js"></script>
<script src="js/map-active.js"></script>

<script src="js/jquery.validate.min.js"></script>
<script src="js/theme.js"></script>
</body>

<!-- Mirrored from paul-themes.com/html/Dimajde/Dimajde-demo/Dimajde/light/home-fullpage.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Aug 2018 11:15:25 GMT -->
</html>