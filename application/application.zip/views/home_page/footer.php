<footer class="footer_area white_f">
    <div class="footer_widgets row m0">
        <aside class="f_widgets_item">
            <div class="f_logo">
                <img class="img-fluid" src="img/logo.png" alt="" />
            </div>
        </aside>
        <aside class="f_widgets_item">
            <div class="f_contact">
                <div class="f_title">
                    <h3><?php echo $footer[0]->footer_title; ?></h3>
                </div>
                <p><?php echo $footer[0]->footer_content; ?></p>
                
               
            </div>
        </aside>
        <aside class="f_widgets_item">
            <div class="f_link">
                <div class="f_title">
                    <h3><?php echo $footer[1]->footer_title; ?></h3>
                </div>
                <ul class="list">
                    <li><a href="http://paul-themes.com/cdn-cgi/l/email-protection#29414c4545466940475d4c5b5a5d5c4d4046074a46"><span class="__cf_email__" data-cfemail="68000d0404072801061c0d1a1b1c1d0c0107460b07"><?php echo $footer[1]->footer_mail; ?></span></a></li>
                    <li><a href="tel:9123548073"><?php echo $footer[1]->footer_mobile; ?></a></li>
                    <li><a href="#"><?php echo $footer[1]->footer_fixed; ?></a></li>
                </ul>
            </div>
        </aside>
        <aside class="f_widgets_item">
            <div class="f_link">
                <div class="f_title">
                    <h3><?php echo $footer[2]->footer_title; ?></h3>
                </div>
                <ul class="list">
                <li><a href="<?php echo footer[2]->twitter_link; ?>"><i class="ion-social-twitter"> Twitter</i></a></li>
                <li><a href="<?php echo footer[2]->fb_link; ?>"><i class="ion-social-facebook"> Facebook</i></a></li>
                <li><a href="<?php echo footer[2]->insta_link; ?>"><i class="ion-social-instagram"> Instagram</i></a></li>
                <li><a href="<?php echo footer[2]->tmb_link; ?>"><i class="ion-social-tumblr"> Tumblr</i></a></li>
                <li><a href="<?php echo footer[2]->pin_link; ?>"><i class="ion-social-pinterest"> Pinterest</i></a></li>
                </ul>
            </div>
            
        </aside>
        <!-- <aside class="f_widgets_item">
            <div class="f_link">
                <div class="f_title">
                    <p>©copyrights 2018, All Rights Reserved for <a href="../index.php">Dimajde</a> Developer BY <img src="./img/targus_logo.ico" href="https://www.targusme.com/"></p>
                </div>
                </ul>
            </div>
        </aside> -->
    <div class="footer_copyright">
        <div class="left_text">
            <p>©copyrights 2018, All Rights Reserved for <a href="./index.php">Dimajde</a> Developed by <a href="https://www.targusme.com/"><img src="./img/targus_logo.ico" /></a></p>
        </div>
    </div>
        <!-- <div class="middle_text">
            <ul class="list">
                <li><a href="#">Twitter</a></li>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Instagram</a></li>
                <li><a href="#">Tumblr</a></li>
                <li><a href="#">Pinterest</a></li>
            </ul>
        </div>
        <div class="right_text">
            <ul class="list">
                <li class="active"><a href="index-rtl.php">Ar</a></li>                        
            </ul>
        </div>
    </div> -->
</footer>
