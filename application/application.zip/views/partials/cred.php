<?php
	define('EMAIL', 'ramadanjamalo@gmail.com');
	define('PASS', '')
?> 
