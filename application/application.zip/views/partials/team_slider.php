<?php

            require_once('phpmailer/class.phpmailer.php');
            require_once('phpmailer/class.smtp.php');
            require_once('phpmailer/PHPMailerAutoload.php');

            $mail = new PHPMailer();


//$mail->SMTPDebug = 3;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'targusme.com';                  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'webmaster@targusme.com';    // SMTP username
$mail->Password = '*123@2018';                         // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$message = "";
$status = "false";
if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
    if ( isset($_POST['sendEmail'] )) {
        if(!empty($_POST['name']) && !empty($_POST['email'])&& !empty($_POST['pos']) && !empty($_POST['opinion'])) {

            $name = $_POST['name'];
            $email = $_POST['email'];
            $pos = $_POST['pos'];

            $opinion = $_POST['opinion'];
            $subject = isset($subject) ? $subject : 'New Message | Job Apply Form';

            $botcheck = $_POST['sendEmail'];

        $toemail =   $_POST["send_email"]; // Receiver Email Address
        $toname = 'magmtl';                // Receiver Name

        if( $botcheck == '' ) {

            $mail->SetFrom( $email , $name );
            $mail->AddReplyTo( $email , $name );
            $mail->AddAddress( $toemail , $toname );
            $mail->Subject = $subject;

            $name = isset($name) ? "Name: $name<br><br>" : '';
            $email = isset($email) ? "Email: $email<br><br>" : '';
            $pos = isset($pos) ? "Message: $pos<br><br>" : '';

            $opinion = isset($opinion) ? "Message: $opinion<br><br>" : '';
           

            $referrer = $_SERVER['HTTP_REFERER'] ? '<br><br><br>This Form was submitted from: ' . $_SERVER['HTTP_REFERER'] : '';

            $body = "$name $email $pos  $opinion $referrer";

            //mail attachment
            if ( isset( $_FILES['form_attachment'] ) && $_FILES['form_attachment']['error'] == UPLOAD_ERR_OK ) {
                $mail->IsHTML(true);
                $mail->AddAttachment( $_FILES['form_attachment']['tmp_name'], $_FILES['form_attachment']['name'] );
            }

            $mail->MsgHTML( $body );
            $sendEmail = $mail->Send();

            if( $sendEmail == true ):

                $status = "true"; 
                echo' <div class="alert alert-success">
                <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span> 
                We have <strong>successfully</strong> received your Message and will get Back to you as soon as possible.
                </div>'
                ?>
                <?php
            else:

                $status = "false";
                echo ' <div class="alert  alert-danger">
                <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span> 
                Email <strong>could not</strong> be sent due to some Unexpected Error. Please Try Again later.<br /><br /><br />
                </div>';?>

                <?php
            endif;
        } else {
            $message = 'Bot <strong>Detected</strong>.! Clean yourself Botster.!';
            $status = "false";
        }
    } else {
        $message = 'Please <strong>Fill up</strong> all the Fields and Try Again.';
        $status = "false";
    }
}
}
?>


<section class="meet_team_area">
										<div class="container">
												<div class="team_inner text-center">													
														<h4><?php echo lang($titles, 'team'); ?></h4>
														<div class="team_slider owl-carousel">
															<?php foreach ($team_slide as $row) {?>
																<div class="item">
																		<div class="team_item">
																				<img src="<?php echo base_url(); ?>assets/img/team/<?php if(isset($row->img)) echo $row->img; ?>" alt="">
																				<div class="hover">
																						<h5><?php echo lang($row, 'name'); ?></h5>
																						<h6><?php echo lang($row, 'pos'); ?></h6>
																						<ul class="list">
																								<li><a href="<?php if(isset($row->twitter)) echo $row->twitter; ?>"><i class="ion-social-twitter"></i></a></li>
																								<li><a href="<?php if(isset($row->fb)) echo $row->fb; ?>"><i class="ion-social-facebook"></i></a></li>
																								<li><a href="<?php if(isset($row->linkedin)) echo $row->linkedin; ?>"><i class="ion-social-linkedin"></i></a></li>
																						</ul>
																				</div>
																		</div>
																</div>
															<?php } ?>																
														</div>

														<?php if(!is_ar_lang()) {?>
														<button type="button" class="btn btn-primary b1a" data-toggle="modal" data-target="#exampleModalCenter6" style="margin-top: 5%">
															
  Join Our Team
</button>
 
<!-- Modal -->
<div class="modal fade" id="exampleModalCenter6" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
      	<img src="./assets/img/CV.svg" alt="" style="width: 4%;">
        <h5 class="modal-title" id="exampleModalCenterTitle">Your Resume...</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="file-loading">
   				 <input id="input-b7" name="input-b7[]" multiple type="file" class="file" data-allowed-file-extensions='["pdf", "doc", "txt"]'>
			</div>
     <div class="modal-footer">        
        <button type="button" class="btn btn-primary" name="uploadCV" title="Your custom upload logic">Upload</button>
      </div>
    </div>
  </div>
</div>

<?php } else { ?>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter6" style="margin-top: 5%;">انضم لفريقنا</button>
 
<!-- Modal -->
<div class="modal fade" id="exampleModalCenter6" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="text-align: right;">
      	<img src="./assets/img/CV.svg" alt="" style="width: 4%;">	
        <h5 class="modal-title" id="exampleModalCenterTitle" style="text-align: right;">سيرتك الذاتية</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="file-loading">
    				<input id="input-b7" name="input-b7[]" multiple type="file" class="file" data-allowed-file-extensions='["pdf", "txt", "doc"]'>
				</div>
        <div id="kartik-file-errors"></div>
      </div>
      <div class="modal-footer">        
        <button type="button" class="btn btn-primary" name="uploadCV" title="Your custom upload logic">إرسال</button>
      </div>
    </div>
  </div>
</div>
	<?php } ?>
 
 
<!-- <script>
$(document).on('ready', function() {
    $("#input-b7").fileinput({
        showPreview: false,
        showUpload: false,
        elErrorContainer: '#kartik-file-errors',
        allowedFileExtensions: ["docx", "pdf", "doc"]
        //uploadUrl: '/site/file-upload-single'
    });
});
</script> -->


							
														
												</div>
										</div>
							</section>														                     

