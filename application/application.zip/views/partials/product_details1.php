<section class="project_villa_area" style="margin-top: 7%;">
			<div class="container">
				<div class="villa_text">
					<h2><?php echo lang($product, 'prod_desc'); ?></h2>
					<p><?php echo lang($product, 'full_desc'); ?></p>
				</div>
				<div class="villa_slider owl-carousel">
					 <?php if(isset($prod_imgs)&& $prod_imgs!=null) {?>
					<?php for ($i=0; $i<count($prod_imgs); ++$i) {?>
					<div class="item">
						<img src="<?php echo base_url(); ?>assets/img/products_by_id/<?php if(isset($prod_imgs[$i]->img)) echo $prod_imgs[$i]->img; ?>" alt="">
					</div>
				<?php } }?>
				
			</div>
		</section>
