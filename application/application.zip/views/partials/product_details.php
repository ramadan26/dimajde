<section class="project_breadcrumb_area"
style="background:url('<?php echo base_url(); ?>assets/img/All_products/<?php if(isset($product->prod_img)) echo $product->prod_img; ?>') no-repeat scroll center center; background-size:cover;">
	
			<div class="container">
				<div class="breadcrumb_inner">
					<div class="breadcrumb_link">
						<a href="#"><?php echo lang($product, 'cate_title'); ?></a>
					</div>
					<div class="bread_bottom_text">
						<h2><?php echo lang($product, 'prod_desc'); ?></h2>
					</div>
				</div>
			</div>
			
		</section>
		
