<section class="clients_area white_cl">
			<div class="container">
				<div class="main_title white">
					
						<h2><?php echo lang($titles, 'clients'); ?></h2>
				</div>
				<div class="testimonials_slider owl-carousel">
					<?php foreach ($client_slider as $row) {?>
					<div class="item">
						<div class="test_item">
							<h4><span><?php echo lang($row, 'name'); ?></span> / <?php echo lang($row, 'pos'); ?></h4>
							<p><?php echo lang($row, 'opinion'); ?></p>
						</div>
					</div>
				<?php }?>
					<!-- <div class="item">
						<div class="test_item">
							<h4><span>Bobs Hanley</span> / Owner of Edden Villa</h4>
							<p>Paras stalor ed elit quam, iaculis sed semper sit amet udin vitae nibh. at magna akal semperFusce commodo molestie luctus.Lorem ipsum vitalun Dolor tusima olatiup aculis sed semper sit ame</p>
						</div>
					</div> -->
				</div>
				
