<section class="project_breadcrumb_area"
style="background:url('<?php echo base_url(); ?>assets/img/All_projects/<?php if(isset($project->img)) echo $project->img; ?>') no-repeat scroll center center; background-size:cover;">
	
			<div class="container">
				<div class="breadcrumb_inner">
					<div class="breadcrumb_link">
						<a href="#"><?php echo lang($project, 'cate_title'); ?></a>
					</div>
					<div class="bread_bottom_text">
						<h2><?php echo lang($project, 'desc'); ?></h2>
					</div>
				</div>
			</div>
			
		</section>
		
