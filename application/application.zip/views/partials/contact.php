 <?php

            require_once('phpmailer/class.phpmailer.php');
            require_once('phpmailer/class.smtp.php');
            require_once('phpmailer/PHPMailerAutoload.php');

            $mail = new PHPMailer();


//$mail->SMTPDebug = 3;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'targusme.com';                  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'webmaster@targusme.com';    // SMTP username
$mail->Password = '*123@2018';                         // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$message = "";
$status = "false";
if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
    if ( isset($_POST['sendEmail'] )) {
        if(!empty($_POST['name']) && !empty($_POST['email'])&& !empty($_POST['pos']) && !empty($_POST['opinion'])) {

            $name = $_POST['name'];
            $email = $_POST['email'];
            $pos = $_POST['pos'];

            $opinion = $_POST['opinion'];
            $subject = isset($subject) ? $subject : 'New Message | Job Apply Form';

            $botcheck = $_POST['sendEmail'];

        $toemail =   $_POST["send_email"]; // Receiver Email Address
        $toname = 'magmtl';                // Receiver Name

        if( $botcheck == '' ) {

            $mail->SetFrom( $email , $name );
            $mail->AddReplyTo( $email , $name );
            $mail->AddAddress( $toemail , $toname );
            $mail->Subject = $subject;

            $name = isset($name) ? "Name: $name<br><br>" : '';
            $email = isset($email) ? "Email: $email<br><br>" : '';
            $pos = isset($pos) ? "Message: $pos<br><br>" : '';

            $opinion = isset($opinion) ? "Message: $opinion<br><br>" : '';
           

            $referrer = $_SERVER['HTTP_REFERER'] ? '<br><br><br>This Form was submitted from: ' . $_SERVER['HTTP_REFERER'] : '';

            $body = "$name $email $pos  $opinion $referrer";

            //mail attachment
            if ( isset( $_FILES['form_attachment'] ) && $_FILES['form_attachment']['error'] == UPLOAD_ERR_OK ) {
                $mail->IsHTML(true);
                $mail->AddAttachment( $_FILES['form_attachment']['tmp_name'], $_FILES['form_attachment']['name'] );
            }

            $mail->MsgHTML( $body );
            $sendEmail = $mail->Send();

            if( $sendEmail == true ):

                $status = "true"; 
                echo' <div class="alert alert-success">
                <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span> 
                We have <strong>successfully</strong> received your Message and will get Back to you as soon as possible.
                </div>'
                ?>
                <?php
            else:

                $status = "false";
                echo ' <div class="alert  alert-danger">
                <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span> 
                Email <strong>could not</strong> be sent due to some Unexpected Error. Please Try Again later.<br /><br /><br />
                </div>';?>

                <?php
            endif;
        } else {
            $message = 'Bot <strong>Detected</strong>.! Clean yourself Botster.!';
            $status = "false";
        }
    } else {
        $message = 'Please <strong>Fill up</strong> all the Fields and Try Again.';
        $status = "false";
    }
}
}
?>

<section class="banner_map">
			<div id="mapBox2" class="mapBox row m0" data-lat="<?php if(isset($con->maplat)) echo $con->maplat; ?>" data-lon="<?php if(isset($con->maplng)) echo $con->maplng; ?>" data-zoom="15" data-marker="assets/img/map-marker.png" data-info="54B, Tailstoi Town 5238 La city, IA 522364" data-mlat="<?php if(isset($con->maplat)) echo $con->maplat; ?>" data-mlon="<?php if(isset($con->maplng)) echo $con->maplng; ?>">
			</div>
		</section>


		<section class="contact_area2">
			<div class="container">
				<div class="row">
					<div class="col-lg-5">
						<div class="left_contact_details">
							
							<h1><?php echo lang($titles, 'contact'); ?></h1>
						
							<h2><span><?php echo lang($con, 'addr'); ?></span></h2>
							<p><?php echo lang($con, 'addr1'); ?></p>
							<a href="tel:<?php if(isset($con->phone)) echo $con->phone; ?>"><?php if(isset($con->phone)) echo $con->phone; ?></a>
							<a href="mailto:<?php if(isset($con->mail)) echo $con->mail; ?>" ><span><?php if(isset($con->mail)) echo $con->mail; ?></span></a>							
						</div>
					</div>
					<div class="col-lg-7">
						<div class="right_contact_form">
							<h4><?php echo lang($titles, 'contact1'); ?></h4>
							<?php if(!is_ar_lang()) {?>
								
							<form method="post" action="<?php echo base_url() ?>contact" class="row contact_us_form js-form">								 
								<div class="form-group col-md-6">
									<input type="text" class="form-control" id="name" name="name" placeholder="Adam Warlock" required>
								</div>
								<div class="form-group col-md-6">
									<input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
								</div>
								<div class="form-group col-md-6">
									<input type="text" class="form-control" id="pos" name="pos" placeholder="Your Position" required>
								</div>
								<div class="form-group col-md-12">
									<textarea class="form-control" name="opinion" id="message" rows="1" placeholder="Here goes your message" required></textarea>
								</div>
								<div class="form-group col-md-12">
									<button type="submit" name="sendEmail" value="submit" class="btn order_s_btn form-control">Send Message <i class="ion-paper-airplane"></i></i></button>
								</div>
								<!-- <div class="success-message"><i class="fa fa-check text-primary"></i> Thank you!. Your message is successfully sent...</div>
								<div class="error-message">We're sorry, but something went wrong</div> -->
								<?php echo $message; ?>
							</form>
							<?php } else { ?>							
							<form method="post" action="<?php echo base_url() ?>contact" class="row contact_us_form js-form">								
								<div class="form-group col-md-6">
									<input type="text" class="form-control" id="name" name="name" placeholder="اكتب اسمك" required>
								</div>
								<div class="form-group col-md-6">
									<input type="email" class="form-control" id="email" name="email" placeholder="الايمل الخاص بك" required>
								</div>
								<div class="form-group col-md-6">
									<input type="text" class="form-control" id="pos" name="pos" placeholder="منصبك الحالي" required>
								</div>
								<div class="form-group col-md-12">
									<textarea class="form-control" name="opinion" id="message" rows="1" placeholder="اكتب رسالتك هنا" required></textarea>
								</div>
								<div class="form-group col-md-12">
									<button type="submit" name="sendEmail" value="submit" class="btn order_s_btn form-control">أرسال<i class="ion-paper-airplane"></i></button>
								</div>												
								<?php echo $message; ?>				
							</form>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</section>

		
          


	<script src="assets/js/jquery-3.3.1.min.js"></script>

	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

	<script src="assets/vendors/revolution/js/jquery.themepunch.tools.min.js"></script>
	<script src="assets/vendors/revolution/js/jquery.themepunch.revolution.min.js"></script>
	<script src="assets/vendors/revolution/js/extensions/revolution.extension.actions.min.js"></script>
	<script src="assets/vendors/revolution/js/extensions/revolution.extension.video.min.js"></script>
	<script src="assets/vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script src="assets/vendors/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script src="assets/vendors/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
	<script src="assets/vendors/revolution/js/extensions/revolution.extension.parallax.min.js"></script>

	<script src="assets/vendors/popup/jquery.magnific-popup.min.js"></script>
	<script src="assets/vendors/parallax/parallax.min.js"></script>
	<script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="assets/vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="assets/vendors/isotope/isotope.pkgd.min.js"></script>
	<script src="assets/vendors/pagepiling/jquery.pagepiling.min.js"></script>
	<script src="assets/vendors/animsition/js/animsition.min.js"></script>
	<script src="assets/js/smoothscroll.js"></script>

	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
	<script src="assets/js/gmaps.min.js"></script>
	<script src="assets/js/map-active.js"></script>
	<script src="assets/js/jquery.validate.min.js"></script>
	<script src="assets/js/theme.js"></script>
